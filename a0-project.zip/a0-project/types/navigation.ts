export type RootStackParamList = {
  Home: undefined;
  Assistant: undefined;
  ImageGenerator: undefined;
  DailyTips: undefined;
  TaskPlanner: undefined;
  Translator: undefined;
};