import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput, 
  FlatList,
  Animated,
  Modal,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, AntDesign } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { Swipeable } from 'react-native-gesture-handler';
import { toast } from 'sonner-native';

interface Task {
  id: string;
  title: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  date: string;
}

export default function TaskPlanner() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [currentPriority, setCurrentPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [askAI, setAskAI] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const navigation = useNavigation();

  // Load demo tasks
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const demoTasks: Task[] = [
      {
        id: '1',
        title: 'Revisar correos pendientes',
        completed: false,
        priority: 'high',
        date: today
      },
      {
        id: '2',
        title: 'Hacer ejercicio 30 minutos',
        completed: false,
        priority: 'medium',
        date: today
      },
      {
        id: '3',
        title: 'Leer un capítulo del libro',
        completed: false,
        priority: 'low',
        date: today
      }
    ];
    
    setTasks(demoTasks);
  }, []);

  const addTask = () => {
    if (!newTaskTitle.trim()) return;
    
    const today = new Date().toISOString().split('T')[0];
    const newTask: Task = {
      id: Date.now().toString(),
      title: newTaskTitle,
      completed: false,
      priority: currentPriority,
      date: today
    };
    
    setTasks(prev => [...prev, newTask]);
    setNewTaskTitle('');
    setCurrentPriority('medium');
    setIsModalVisible(false);
    toast.success('Tarea añadida');
  };

  const updateTask = () => {
    if (!editingTask || !editingTask.title.trim()) return;
    
    setTasks(prev => 
      prev.map(task => 
        task.id === editingTask.id 
          ? { ...editingTask, priority: currentPriority } 
          : task
      )
    );
    
    setEditingTask(null);
    setIsModalVisible(false);
    toast.success('Tarea actualizada');
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
    toast.success('Tarea eliminada');
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === id 
          ? { ...task, completed: !task.completed } 
          : task
      )
    );
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setCurrentPriority(task.priority);
    setIsModalVisible(true);
  };

  const priorityColors = {
    low: '#4ECDC4',    // Turquoise
    medium: '#FFD166', // Yellow
    high: '#FF6B6B'    // Red
  };

  const getPriorityLabel = (priority: 'low' | 'medium' | 'high') => {
    switch (priority) {
      case 'low': return 'Baja';
      case 'medium': return 'Media';
      case 'high': return 'Alta';
    }
  };

  const getAISuggestion = async () => {
    if (aiLoading) return;
    setAiLoading(true);
    
    try {
      const tasksList = tasks.map(t => t.title).join(', ');
      
      const response = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            { 
              role: 'system', 
              content: 'Eres un asistente de productividad que ayuda a organizar tareas. Responde en español con sugerencias claras y concisas.' 
            },
            { 
              role: 'user', 
              content: `Basado en mis tareas actuales: [${tasksList}], ¿qué otra tarea importante podría añadir a mi lista para hoy? Responde con una sola tarea completa, sin introducción ni explicación.` 
            }
          ]
        }),
      });
      
      const data = await response.json();
      setAiSuggestion(data.completion);
    } catch (error) {
      console.error(error);
      setAiSuggestion('No se pudo obtener una sugerencia. Inténtalo de nuevo.');
    } finally {
      setAiLoading(false);
    }
  };

  const useAISuggestion = () => {
    if (aiSuggestion) {
      setNewTaskTitle(aiSuggestion);
      setAskAI(false);
    }
  };

  const renderSwipeableTask = ({ item }: { item: Task }) => {
    let swipeableRef: Swipeable | null = null;

    const renderRightActions = (progress: Animated.AnimatedInterpolation<number>) => {
      const trans = progress.interpolate({
        inputRange: [0, 1],
        outputRange: [64, 0],
      });
      
      return (
        <View style={styles.rightActions}>
          <Animated.View style={{ transform: [{ translateX: trans }] }}>
            <TouchableOpacity 
              style={[styles.actionButton, styles.editButton]} 
              onPress={() => {
                swipeableRef?.close();
                openEditModal(item);
              }}
            >
              <MaterialIcons name="edit" size={20} color="#FFF" />
            </TouchableOpacity>
          </Animated.View>
          <Animated.View style={{ transform: [{ translateX: trans }] }}>
            <TouchableOpacity 
              style={[styles.actionButton, styles.deleteButton]} 
              onPress={() => {
                swipeableRef?.close();
                deleteTask(item.id);
              }}
            >
              <MaterialIcons name="delete" size={20} color="#FFF" />
            </TouchableOpacity>
          </Animated.View>
        </View>
      );
    };
    
    return (
      <Swipeable
        ref={ref => swipeableRef = ref}
        renderRightActions={renderRightActions}
        rightThreshold={40}
      >
        <TouchableOpacity 
          style={styles.taskItem}
          onPress={() => toggleTaskCompletion(item.id)}
        >
          <View style={styles.taskCheckAndTitle}>
            <TouchableOpacity 
              style={[
                styles.checkbox,
                item.completed && styles.checkboxChecked
              ]}
              onPress={() => toggleTaskCompletion(item.id)}
            >
              {item.completed && <Ionicons name="checkmark" size={18} color="white" />}
            </TouchableOpacity>
            <Text 
              style={[
                styles.taskTitle,
                item.completed && styles.taskTitleCompleted
              ]}
            >
              {item.title}
            </Text>
          </View>
          <View style={styles.taskMeta}>
            <View 
              style={[
                styles.priorityBadge, 
                { backgroundColor: priorityColors[item.priority] }
              ]}
            >
              <Text style={styles.priorityText}>
                {getPriorityLabel(item.priority)}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </Swipeable>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Planificador de Tareas</Text>
        <View style={{ width: 24 }} />
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{tasks.length}</Text>
          <Text style={styles.statLabel}>Total</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>
            {tasks.filter(task => task.completed).length}
          </Text>
          <Text style={styles.statLabel}>Completadas</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>
            {tasks.filter(task => task.priority === 'high' && !task.completed).length}
          </Text>
          <Text style={styles.statLabel}>Prioritarias</Text>
        </View>
      </View>
      
      <FlatList
        data={tasks}
        renderItem={renderSwipeableTask}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.tasksList}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <MaterialIcons name="check-circle" size={64} color="#CCCCCC" />
            <Text style={styles.emptyText}>¡No hay tareas pendientes!</Text>
            <Text style={styles.emptySubtext}>Añade una nueva tarea para comenzar</Text>
          </View>
        }
      />
      
      <TouchableOpacity 
        style={styles.addButton}
        onPress={() => {
          setEditingTask(null);
          setNewTaskTitle('');
          setCurrentPriority('medium');
          setIsModalVisible(true);
        }}
      >
        <AntDesign name="plus" size={24} color="white" />
      </TouchableOpacity>
      
      {/* Modal para añadir/editar tarea */}
      <Modal
        visible={isModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsModalVisible(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setIsModalVisible(false)}>
                <AntDesign name="close" size={24} color="#333" />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>
                {editingTask ? 'Editar Tarea' : 'Nueva Tarea'}
              </Text>
              <View style={{ width: 24 }} />
            </View>
            
            <ScrollView style={styles.modalBody}>
              <Text style={styles.inputLabel}>Título de la tarea</Text>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.taskInput}
                  value={editingTask ? editingTask.title : newTaskTitle}
                  onChangeText={(text) => {
                    if (editingTask) {
                      setEditingTask({ ...editingTask, title: text });
                    } else {
                      setNewTaskTitle(text);
                    }
                  }}
                  placeholder="¿Qué necesitas hacer?"
                  placeholderTextColor="#999"
                />
                
                {!editingTask && (
                  <TouchableOpacity 
                    style={styles.aiButton}
                    onPress={() => setAskAI(true)}
                  >
                    <MaterialCommunityIcons name="robot" size={24} color="#0066FF" />
                  </TouchableOpacity>
                )}
              </View>
              
              {askAI && (
                <View style={styles.aiSuggestionContainer}>
                  <View style={styles.aiSuggestionHeader}>
                    <Text style={styles.aiSuggestionTitle}>Sugerencia IA</Text>
                    <TouchableOpacity onPress={() => setAskAI(false)}>
                      <AntDesign name="close" size={20} color="#666" />
                    </TouchableOpacity>
                  </View>
                  
                  {aiLoading ? (
                    <View style={styles.aiLoading}>
                      <Text style={styles.aiLoadingText}>Pensando...</Text>
                    </View>
                  ) : aiSuggestion ? (
                    <View style={styles.aiSuggestionResult}>
                      <Text style={styles.aiSuggestionText}>{aiSuggestion}</Text>
                      <TouchableOpacity 
                        style={styles.useAiButton} 
                        onPress={useAISuggestion}
                      >
                        <Text style={styles.useAiButtonText}>Utilizar esta sugerencia</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <View style={styles.aiSuggestionPrompt}>
                      <Text style={styles.aiPromptText}>Obtén una sugerencia basada en tus tareas actuales</Text>
                      <TouchableOpacity 
                        style={styles.getAiButton} 
                        onPress={getAISuggestion}
                      >
                        <Text style={styles.getAiButtonText}>Generar sugerencia</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              )}
              
              <Text style={styles.inputLabel}>Prioridad</Text>
              <View style={styles.prioritySelector}>
                <TouchableOpacity
                  style={[
                    styles.priorityOption,
                    currentPriority === 'low' && styles.priorityOptionSelected,
                    { borderColor: priorityColors.low }
                  ]}
                  onPress={() => setCurrentPriority('low')}
                >
                  <View style={[styles.priorityDot, { backgroundColor: priorityColors.low }]} />
                  <Text style={styles.priorityOptionText}>Baja</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.priorityOption,
                    currentPriority === 'medium' && styles.priorityOptionSelected,
                    { borderColor: priorityColors.medium }
                  ]}
                  onPress={() => setCurrentPriority('medium')}
                >
                  <View style={[styles.priorityDot, { backgroundColor: priorityColors.medium }]} />
                  <Text style={styles.priorityOptionText}>Media</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.priorityOption,
                    currentPriority === 'high' && styles.priorityOptionSelected,
                    { borderColor: priorityColors.high }
                  ]}
                  onPress={() => setCurrentPriority('high')}
                >
                  <View style={[styles.priorityDot, { backgroundColor: priorityColors.high }]} />
                  <Text style={styles.priorityOptionText}>Alta</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
            
            <TouchableOpacity 
              style={styles.saveButton}
              onPress={editingTask ? updateTask : addTask}
              disabled={(editingTask ? !editingTask.title : !newTaskTitle).trim()}
            >
              <Text style={styles.saveButtonText}>
                {editingTask ? 'Actualizar' : 'Añadir Tarea'}
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
    backgroundColor: 'white',
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  tasksList: {
    padding: 16,
    paddingBottom: 100,
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  taskCheckAndTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#0066FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  checkboxChecked: {
    backgroundColor: '#0066FF',
  },
  taskTitle: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  taskTitleCompleted: {
    textDecorationLine: 'line-through',
    color: '#999',
  },
  taskMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  priorityText: {
    fontSize: 12,
    color: 'white',
    fontWeight: '500',
  },
  rightActions: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 120,
    justifyContent: 'space-between',
  },
  actionButton: {
    width: 55,
    height: '88%',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
  },
  editButton: {
    backgroundColor: '#4ECDC4',
  },
  deleteButton: {
    backgroundColor: '#FF6B6B',
  },
  addButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#0066FF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  modalBody: {
    padding: 16,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  taskInput: {
    flex: 1,
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
  },
  aiButton: {
    marginLeft: 8,
    padding: 8,
  },
  prioritySelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  priorityOption: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderWidth: 2,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  priorityOptionSelected: {
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
  },
  priorityDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    marginBottom: 6,
  },
  priorityOptionText: {
    fontSize: 14,
    color: '#333',
  },
  saveButton: {
    backgroundColor: '#0066FF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
    textAlign: 'center',
  },
  aiSuggestionContainer: {
    backgroundColor: '#F7F9FC',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
  },
  aiSuggestionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  aiSuggestionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  aiSuggestionPrompt: {
    alignItems: 'center',
    padding: 8,
  },
  aiPromptText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 12,
  },
  getAiButton: {
    backgroundColor: '#0066FF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  getAiButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  aiLoading: {
    alignItems: 'center',
    padding: 20,
  },
  aiLoadingText: {
    color: '#666',
    marginTop: 8,
  },
  aiSuggestionResult: {
    padding: 8,
  },
  aiSuggestionText: {
    fontSize: 15,
    color: '#333',
    marginBottom: 12,
  },
  useAiButton: {
    backgroundColor: '#0066FF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'center',
  },
  useAiButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});