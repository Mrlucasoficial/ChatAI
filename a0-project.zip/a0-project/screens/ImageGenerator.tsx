import React, { useState, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  ActivityIndicator,
  Dimensions,
  Share,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, FontAwesome, MaterialIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as Clipboard from 'expo-clipboard';
import { toast } from 'sonner-native';

const { width } = Dimensions.get('window');

type AspectRatio = '1:1' | '16:9' | '9:16' | '4:5' | '5:4';

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [selectedAspect, setSelectedAspect] = useState<AspectRatio>('1:1');
  const [recentPrompts, setRecentPrompts] = useState<string[]>([]);
  const navigation = useNavigation();
  const scrollViewRef = useRef<ScrollView>(null);

  const aspectRatios: { label: string; value: AspectRatio }[] = [
    { label: 'Cuadrado', value: '1:1' },
    { label: 'Horizontal', value: '16:9' },
    { label: 'Vertical', value: '9:16' },
    { label: 'Retrato', value: '4:5' },
    { label: 'Paisaje', value: '5:4' },
  ];

  const generateImage = async () => {
    if (prompt.trim() === '') return;
    
    setIsGenerating(true);
    
    try {
      const encodedPrompt = encodeURIComponent(prompt);
      const imageUrl = `https://api.a0.dev/assets/image?text=${encodedPrompt}&aspect=${selectedAspect}`;
      
      setGeneratedImage(imageUrl);
      
      // Add to recent prompts
      if (!recentPrompts.includes(prompt)) {
        setRecentPrompts(prev => [prompt, ...prev.slice(0, 4)]);
      }
      
      setTimeout(() => {
        scrollViewRef.current?.scrollTo({ y: 0, animated: true });
      }, 300);
    } catch (error) {
      console.error(error);
      toast.error('Error al generar la imagen. Inténtalo de nuevo.');
    } finally {
      setIsGenerating(false);
    }
  };

  const shareImage = async () => {
    if (!generatedImage) return;
    
    try {
      await Share.share({
        message: 'Mira esta imagen que generé con IA',
        url: generatedImage
      });
    } catch (error) {
      console.error(error);
    }
  };

  const copyImageUrl = async () => {
    if (!generatedImage) return;
    
    try {
      await Clipboard.setStringAsync(generatedImage);
      toast.success('URL copiada al portapapeles');
    } catch (error) {
      console.error(error);
    }
  };

  const useRecentPrompt = (prompt: string) => {
    setPrompt(prompt);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Generador de Imágenes</Text>
        <View style={{ width: 24 }} />
      </View>
      
      <ScrollView
        ref={scrollViewRef}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {generatedImage && (
          <View style={styles.imageContainer}>
            <Image
              source={{ uri: generatedImage }}
              style={[
                styles.generatedImage,
                selectedAspect === '16:9' && { height: width * 9/16 },
                selectedAspect === '9:16' && { height: width * 16/9 },
                selectedAspect === '4:5' && { height: width * 5/4 },
                selectedAspect === '5:4' && { height: width * 4/5 }
              ]}
              resizeMode="cover"
            />
            
            <View style={styles.imageActions}>
              <TouchableOpacity style={styles.imageAction} onPress={shareImage}>
                <Ionicons name="share-outline" size={22} color="#333" />
                <Text style={styles.actionText}>Compartir</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.imageAction} onPress={copyImageUrl}>
                <MaterialIcons name="content-copy" size={22} color="#333" />
                <Text style={styles.actionText}>Copiar URL</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        <View style={styles.formContainer}>
          <Text style={styles.sectionTitle}>Elige un formato</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.aspectRatioContainer}
          >
            {aspectRatios.map((aspect) => (
              <TouchableOpacity
                key={aspect.value}
                style={[
                  styles.aspectRatioButton,
                  selectedAspect === aspect.value && styles.selectedAspectRatio
                ]}
                onPress={() => setSelectedAspect(aspect.value)}
              >
                <Text
                  style={[
                    styles.aspectRatioText,
                    selectedAspect === aspect.value && styles.selectedAspectRatioText
                  ]}
                >
                  {aspect.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          <Text style={styles.sectionTitle}>Describe tu imagen</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={prompt}
              onChangeText={setPrompt}
              placeholder="Describe la imagen que quieres generar..."
              placeholderTextColor="#999"
              multiline
              maxLength={500}
            />
          </View>
          
          <TouchableOpacity
            style={[styles.generateButton, !prompt.trim() && styles.disabledButton]}
            onPress={generateImage}
            disabled={!prompt.trim() || isGenerating}
          >
            {isGenerating ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <FontAwesome name="magic" size={18} color="#FFFFFF" style={styles.buttonIcon} />
                <Text style={styles.generateButtonText}>Generar Imagen</Text>
              </>
            )}
          </TouchableOpacity>
          
          {recentPrompts.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>Prompts recientes</Text>
              <View style={styles.recentPromptsContainer}>
                {recentPrompts.map((recentPrompt, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.recentPromptItem}
                    onPress={() => useRecentPrompt(recentPrompt)}
                  >
                    <Ionicons name="time-outline" size={16} color="#666" />
                    <Text style={styles.recentPromptText} numberOfLines={1}>
                      {recentPrompt}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
    backgroundColor: 'white',
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  scrollContent: {
    padding: 16,
  },
  imageContainer: {
    marginBottom: 24,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  generatedImage: {
    width: '100%',
    height: width,
    backgroundColor: '#F0F0F0',
  },
  imageActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  imageAction: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
  },
  actionText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 6,
  },
  formContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  aspectRatioContainer: {
    paddingBottom: 8,
  },
  aspectRatioButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
    marginRight: 8,
    marginBottom: 8,
  },
  selectedAspectRatio: {
    backgroundColor: '#0066FF',
  },
  aspectRatioText: {
    fontSize: 14,
    color: '#666',
  },
  selectedAspectRatioText: {
    color: 'white',
    fontWeight: '600',
  },
  inputContainer: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    color: '#333',
    minHeight: 100,
    textAlignVertical: 'top',
  },
  generateButton: {
    backgroundColor: '#0066FF',
    borderRadius: 8,
    paddingVertical: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  buttonIcon: {
    marginRight: 8,
  },
  generateButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  disabledButton: {
    backgroundColor: '#CCCCCC',
  },
  recentPromptsContainer: {
    marginBottom: 16,
  },
  recentPromptItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  recentPromptText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 8,
    flex: 1,
  },
});