import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  Image, 
  TextInput,
  ActivityIndicator
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types/navigation';

// Componente principal de la pantalla Home
export default function HomeScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [greeting, setGreeting] = useState('Buenos días');
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');
  const [weather, setWeather] = useState({ temp: '24°', condition: 'Soleado' });

  // Actualizar el saludo según la hora del día
  useEffect(() => {
    const date = new Date();
    const hour = date.getHours();
    
    if (hour >= 5 && hour < 12) {
      setGreeting('Buenos días');
    } else if (hour >= 12 && hour < 19) {
      setGreeting('Buenas tardes');
    } else {
      setGreeting('Buenas noches');
    }

    // Formatear la hora actual
    const formattedTime = date.toLocaleTimeString('es-ES', { 
      hour: '2-digit', 
      minute: '2-digit'
    });
    setCurrentTime(formattedTime);
    
    // Formatear la fecha actual
    const formattedDate = date.toLocaleDateString('es-ES', {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });
    setCurrentDate(formattedDate.charAt(0).toUpperCase() + formattedDate.slice(1));
    
    // Actualizar cada minuto
    const timer = setInterval(() => {
      const newDate = new Date();
      setCurrentTime(newDate.toLocaleTimeString('es-ES', { 
        hour: '2-digit', 
        minute: '2-digit'
      }));
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Cabecera con información del tiempo */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{greeting}</Text>
            <Text style={styles.date}>{currentDate}</Text>
          </View>
          <View style={styles.weatherContainer}>
            <Text style={styles.temperature}>{weather.temp}</Text>
            <Text style={styles.weatherCondition}>{weather.condition}</Text>
          </View>
        </View>

        {/* Sección del asistente virtual */}
        <TouchableOpacity 
          style={styles.assistantCard}
          onPress={() => navigation.navigate('Assistant')}
        >
          <LinearGradient
            colors={['#4c669f', '#3b5998', '#192f6a']}
            style={styles.gradientBackground}
          >
            <View style={styles.assistantContent}>
              <MaterialCommunityIcons name="robot" size={36} color="white" />
              <View style={styles.assistantTextContainer}>
                <Text style={styles.assistantTitle}>Asistente IA</Text>
                <Text style={styles.assistantSubtitle}>Pregúntame lo que necesites</Text>
              </View>
              <Feather name="chevron-right" size={24} color="white" />
            </View>
          </LinearGradient>
        </TouchableOpacity>

        {/* Sección de herramientas IA */}
        <Text style={styles.sectionTitle}>Herramientas IA</Text>
        <View style={styles.toolsGrid}>
          <TouchableOpacity 
            style={styles.toolCard}
            onPress={() => navigation.navigate('ImageGenerator')}
          >
            <View style={[styles.toolIconContainer, { backgroundColor: '#FF6B6B' }]}>
              <Ionicons name="image" size={24} color="white" />
            </View>
            <Text style={styles.toolName}>Generar Imágenes</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.toolCard}
            onPress={() => navigation.navigate('DailyTips')}
          >
            <View style={[styles.toolIconContainer, { backgroundColor: '#4ECDC4' }]}>
              <Feather name="list" size={24} color="white" />
            </View>
            <Text style={styles.toolName}>Tips Diarios</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.toolCard}
            onPress={() => navigation.navigate('Translator')}
          >
            <View style={[styles.toolIconContainer, { backgroundColor: '#6A0572' }]}>
              <MaterialCommunityIcons name="translate" size={24} color="white" />
            </View>
            <Text style={styles.toolName}>Traductor IA</Text>
          </TouchableOpacity>
        </View>

        {/* Sección de actividades sugeridas */}
        <Text style={styles.sectionTitle}>Sugerencias para hoy</Text>
        <View style={styles.suggestionsContainer}>
          <TouchableOpacity style={styles.suggestionCard}>
            <Image 
              source={{ uri: 'https://api.a0.dev/assets/image?text=person%20meditating%20peaceful%20morning&aspect=16:9' }} 
              style={styles.suggestionImage} 
            />
            <View style={styles.suggestionContent}>
              <Text style={styles.suggestionTitle}>10 min de meditación</Text>
              <Text style={styles.suggestionDescription}>Comienza tu día con calma y enfoque</Text>
            </View>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.suggestionCard}>
            <Image 
              source={{ uri: 'https://api.a0.dev/assets/image?text=organized%20daily%20planner%20productivity&aspect=16:9' }} 
              style={styles.suggestionImage} 
            />
            <View style={styles.suggestionContent}>
              <Text style={styles.suggestionTitle}>Planifica tu día</Text>
              <Text style={styles.suggestionDescription}>Organiza tus tareas con IA</Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginTop: 12,
    marginBottom: 24,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  date: {
    fontSize: 16,
    color: '#666',
    marginTop: 4,
  },
  weatherContainer: {
    alignItems: 'flex-end',
  },
  temperature: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  weatherCondition: {
    fontSize: 14,
    color: '#666',
  },
  assistantCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  gradientBackground: {
    borderRadius: 16,
    padding: 20,
  },
  assistantContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  assistantTextContainer: {
    flex: 1,
    marginLeft: 16,
  },
  assistantTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  assistantSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 16,
  },
  toolsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  toolCard: {
    width: '48%',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  toolIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  toolName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  suggestionsContainer: {
    marginBottom: 24,
  },
  suggestionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  suggestionImage: {
    width: '100%',
    height: 120,
  },
  suggestionContent: {
    padding: 12,
  },
  suggestionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  suggestionDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
});