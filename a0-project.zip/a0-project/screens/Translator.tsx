import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput, 
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialIcons, Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import * as Clipboard from 'expo-clipboard';
import { toast } from 'sonner-native';

interface Language {
  code: string;
  name: string;
}

export default function Translator() {
  const [text, setText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [sourceLanguage, setSourceLanguage] = useState<Language>({ code: 'es', name: 'Español' });
  const [targetLanguage, setTargetLanguage] = useState<Language>({ code: 'en', name: 'Inglés' });
  const [showLanguages, setShowLanguages] = useState<'source' | 'target' | null>(null);
  const navigation = useNavigation();

  const languages: Language[] = [
    { code: 'es', name: 'Español' },
    { code: 'en', name: 'Inglés' },
    { code: 'fr', name: 'Francés' },
    { code: 'de', name: 'Alemán' },
    { code: 'it', name: 'Italiano' },
    { code: 'pt', name: 'Portugués' },
    { code: 'ru', name: 'Ruso' },
    { code: 'zh', name: 'Chino' },
    { code: 'ja', name: 'Japonés' },
    { code: 'ar', name: 'Árabe' },
  ];

  const translateText = async () => {
    if (!text.trim()) return;
    
    setIsTranslating(true);
    
    try {
      const response = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: [
            { 
              role: 'system', 
              content: `Eres un traductor profesional. Traduce el siguiente texto de ${sourceLanguage.name} a ${targetLanguage.name}. Solo proporciona la traducción sin explicaciones o comentarios adicionales.` 
            },
            { role: 'user', content: text }
          ]
        }),
      });
      
      const data = await response.json();
      setTranslatedText(data.completion);
    } catch (error) {
      console.error(error);
      toast.error('Error al traducir. Inténtalo de nuevo.');
    } finally {
      setIsTranslating(false);
    }
  };

  const swapLanguages = () => {
    const temp = sourceLanguage;
    setSourceLanguage(targetLanguage);
    setTargetLanguage(temp);
    
    // Also swap text
    setText(translatedText);
    setTranslatedText(text);
  };

  const copyToClipboard = async (textToCopy: string) => {
    try {
      await Clipboard.setStringAsync(textToCopy);
      toast.success('Texto copiado al portapapeles');
    } catch (error) {
      console.error(error);
    }
  };

  const selectLanguage = (language: Language) => {
    if (showLanguages === 'source') {
      setSourceLanguage(language);
    } else if (showLanguages === 'target') {
      setTargetLanguage(language);
    }
    
    setShowLanguages(null);
  };

  const clearText = () => {
    setText('');
    setTranslatedText('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Traductor IA</Text>
        <TouchableOpacity onPress={clearText} style={styles.clearButton}>
          <MaterialIcons name="delete-outline" size={24} color="#333" />
        </TouchableOpacity>
      </View>
      
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.content}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Language selector */}
          <View style={styles.languageSelector}>
            <TouchableOpacity 
              style={styles.languageButton}
              onPress={() => setShowLanguages('source')}
            >
              <Text style={styles.languageButtonText}>{sourceLanguage.name}</Text>
              <Ionicons name="chevron-down" size={16} color="#666" />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.swapButton}
              onPress={swapLanguages}
            >
              <Ionicons name="swap-horizontal" size={20} color="#0066FF" />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.languageButton}
              onPress={() => setShowLanguages('target')}
            >
              <Text style={styles.languageButtonText}>{targetLanguage.name}</Text>
              <Ionicons name="chevron-down" size={16} color="#666" />
            </TouchableOpacity>
          </View>
          
          {/* Source text input */}
          <View style={styles.textBox}>
            <TextInput
              style={styles.textInput}
              value={text}
              onChangeText={setText}
              placeholder="Escribe texto para traducir"
              placeholderTextColor="#999"
              multiline
              textAlignVertical="top"
              maxLength={1000}
            />
            <View style={styles.textBoxFooter}>
              <Text style={styles.charCount}>{text.length}/1000</Text>
              
              {text && (
                <TouchableOpacity onPress={() => copyToClipboard(text)}>
                  <Feather name="copy" size={18} color="#666" />
                </TouchableOpacity>
              )}
            </View>
          </View>
          
          {/* Translate button */}
          <TouchableOpacity 
            style={[styles.translateButton, !text.trim() && styles.disabledButton]}
            onPress={translateText}
            disabled={!text.trim() || isTranslating}
          >
            {isTranslating ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Text style={styles.translateButtonText}>Traducir</Text>
            )}
          </TouchableOpacity>
          
          {/* Translated text */}
          {translatedText && (
            <View style={styles.resultBox}>
              <Text style={styles.resultTitle}>Traducción:</Text>
              <Text style={styles.translatedText}>{translatedText}</Text>
              
              <View style={styles.resultActions}>
                <TouchableOpacity 
                  style={styles.resultAction}
                  onPress={() => copyToClipboard(translatedText)}
                >
                  <Feather name="copy" size={18} color="#666" />
                  <Text style={styles.resultActionText}>Copiar</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.resultAction}
                  onPress={() => {
                    setText(translatedText);
                    setTranslatedText('');
                    swapLanguages();
                  }}
                >
                  <MaterialIcons name="swap-vert" size={18} color="#666" />
                  <Text style={styles.resultActionText}>Invertir</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
      
      {/* Language selection modal */}
      {showLanguages && (
        <View style={styles.languageModal}>
          <View style={styles.languageModalContent}>
            <View style={styles.languageModalHeader}>
              <Text style={styles.languageModalTitle}>
                Selecciona un idioma
              </Text>
              <TouchableOpacity onPress={() => setShowLanguages(null)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.languageList}>
              {languages.map((language) => (
                <TouchableOpacity
                  key={language.code}
                  style={[
                    styles.languageOption,
                    ((showLanguages === 'source' && sourceLanguage.code === language.code) ||
                     (showLanguages === 'target' && targetLanguage.code === language.code)) &&
                      styles.selectedLanguage
                  ]}
                  onPress={() => selectLanguage(language)}
                >
                  <Text style={styles.languageOptionText}>{language.name}</Text>
                  {((showLanguages === 'source' && sourceLanguage.code === language.code) ||
                    (showLanguages === 'target' && targetLanguage.code === language.code)) && (
                    <Ionicons name="checkmark" size={20} color="#0066FF" />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
    backgroundColor: 'white',
  },
  backButton: {
    padding: 4,
  },
  clearButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  languageSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  languageButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  languageButtonText: {
    fontSize: 16,
    color: '#333',
    marginRight: 6,
  },
  swapButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  textBox: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    minHeight: 150,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  textInput: {
    fontSize: 16,
    color: '#333',
    minHeight: 120,
  },
  textBoxFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  charCount: {
    fontSize: 12,
    color: '#999',
  },
  translateButton: {
    backgroundColor: '#0066FF',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginBottom: 24,
  },
  translateButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  disabledButton: {
    backgroundColor: '#CCCCCC',
  },
  resultBox: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  resultTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
  },
  translatedText: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
  },
  resultActions: {
    flexDirection: 'row',
    marginTop: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  resultAction: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  resultActionText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  languageModal: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  languageModalContent: {
    backgroundColor: 'white',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '70%',
  },
  languageModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  languageModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  languageList: {
    padding: 8,
  },
  languageOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  selectedLanguage: {
    backgroundColor: 'rgba(0, 102, 255, 0.05)',
  },
  languageOptionText: {
    fontSize: 16,
    color: '#333',
  },
});