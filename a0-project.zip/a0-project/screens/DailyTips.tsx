import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  Image,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

interface Tip {
  id: string;
  title: string;
  content: string;
  category: 'productividad' | 'salud' | 'bienestar' | 'aprendizaje';
  imageUrl: string;
}

const CATEGORIES = [
  { id: 'all', name: 'Todos' },
  { id: 'productividad', name: 'Productividad' },
  { id: 'salud', name: 'Salud' },
  { id: 'bienestar', name: 'Bienestar' },
  { id: 'aprendizaje', name: 'Aprendizaje' },
];

export default function DailyTips() {
  const [tips, setTips] = useState<Tip[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const navigation = useNavigation();

  const loadTips = async () => {
    setLoading(true);
    
    try {
      // Simulating API call with AI-generated tips
      const generatedTips: Tip[] = [
        {
          id: '1',
          title: 'Técnica Pomodoro',
          content: 'Trabaja en intervalos de 25 minutos con descansos cortos. Esta técnica puede aumentar tu concentración y productividad significativamente.',
          category: 'productividad',
          imageUrl: 'https://api.a0.dev/assets/image?text=tomato%20timer%20pomodoro%20technique&aspect=16:9'
        },
        {
          id: '2',
          title: 'Hidratación adecuada',
          content: 'Beber al menos 2 litros de agua al día mejora la concentración, el metabolismo y la salud en general.',
          category: 'salud',
          imageUrl: 'https://api.a0.dev/assets/image?text=glass%20of%20water%20hydration%20health&aspect=16:9'
        },
        {
          id: '3',
          title: 'Meditación diaria',
          content: 'Dedica 10 minutos cada mañana a la meditación. Reduce el estrés y mejora la claridad mental durante todo el día.',
          category: 'bienestar',
          imageUrl: 'https://api.a0.dev/assets/image?text=peaceful%20meditation%20morning%20routine&aspect=16:9'
        },
        {
          id: '4',
          title: 'Aprendizaje activo',
          content: 'Explica lo que has aprendido a alguien más. Enseñar es una de las mejores formas de reforzar conocimientos nuevos.',
          category: 'aprendizaje',
          imageUrl: 'https://api.a0.dev/assets/image?text=person%20teaching%20explaining%20concept&aspect=16:9'
        },
        {
          id: '5',
          title: 'Método 2-Minutos',
          content: 'Si una tarea toma menos de 2 minutos, hazla inmediatamente en lugar de posponerla. Evitarás acumular pequeñas tareas.',
          category: 'productividad',
          imageUrl: 'https://api.a0.dev/assets/image?text=stopwatch%202%20minutes%20productivity%20hack&aspect=16:9'
        },
      ];
      
      setTips(generatedTips);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadTips();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    loadTips();
  };

  const filteredTips = selectedCategory === 'all' 
    ? tips 
    : tips.filter(tip => tip.category === selectedCategory);

  // Get the category icon
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'productividad':
        return <MaterialCommunityIcons name="lightning-bolt" size={18} color="#FF6B6B" />;
      case 'salud':
        return <Ionicons name="fitness" size={18} color="#4ECDC4" />;
      case 'bienestar':
        return <MaterialCommunityIcons name="meditation" size={18} color="#9B59B6" />;
      case 'aprendizaje':
        return <Ionicons name="book" size={18} color="#3498DB" />;
      default:
        return <Ionicons name="star" size={18} color="#666" />;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Tips Diarios</Text>
        <View style={{ width: 24 }} />
      </View>
      
      {/* Categories */}
      <View style={styles.categoriesContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContent}
        >
          {CATEGORIES.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton,
                selectedCategory === category.id && styles.selectedCategory
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text 
                style={[
                  styles.categoryText,
                  selectedCategory === category.id && styles.selectedCategoryText
                ]}
              >
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      
      {/* Tips List */}
      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0066FF" />
          <Text style={styles.loadingText}>Cargando tips...</Text>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.tipsContainer}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#0066FF']}
            />
          }
        >
          {filteredTips.length === 0 ? (
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons name="lightbulb-outline" size={64} color="#CCCCCC" />
              <Text style={styles.emptyText}>No hay tips en esta categoría</Text>
            </View>
          ) : (
            filteredTips.map(tip => (
              <View key={tip.id} style={styles.tipCard}>
                <Image
                  source={{ uri: tip.imageUrl }}
                  style={styles.tipImage}
                  resizeMode="cover"
                />
                <View style={styles.tipContent}>
                  <View style={styles.tipHeader}>
                    {getCategoryIcon(tip.category)}
                    <Text style={styles.tipCategory}>
                      {CATEGORIES.find(cat => cat.id === tip.category)?.name || 'General'}
                    </Text>
                  </View>
                  <Text style={styles.tipTitle}>{tip.title}</Text>
                  <Text style={styles.tipDescription}>{tip.content}</Text>
                </View>
              </View>
            ))
          )}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
    backgroundColor: 'white',
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  categoriesContainer: {
    backgroundColor: 'white',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  categoriesContent: {
    paddingHorizontal: 16,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
    marginRight: 8,
  },
  selectedCategory: {
    backgroundColor: '#0066FF',
  },
  categoryText: {
    fontSize: 14,
    color: '#666',
  },
  selectedCategoryText: {
    color: 'white',
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  tipsContainer: {
    padding: 16,
    paddingBottom: 24,
  },
  tipCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tipImage: {
    width: '100%',
    height: 160,
  },
  tipContent: {
    padding: 16,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tipCategory: {
    fontSize: 13,
    color: '#666',
    marginLeft: 6,
  },
  tipTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  tipDescription: {
    fontSize: 15,
    color: '#444',
    lineHeight: 22,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 12,
    textAlign: 'center',
  },
});